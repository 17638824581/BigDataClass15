import ElButtonGroup from '../button/src/button-group.vue';

/* istanbul ignore next */
ElButtonGroup.install = function(Vue) {
  Vue.component(ElButtonGroup.name, ElButtonGroup);
};

export default ElButtonGroup;
