import Statistic from './src/main.vue';

/* istanbul ignore next */
Statistic.install = function(Vue) {
  Vue.component(Statistic.name, Statistic);
};

export default Statistic;
